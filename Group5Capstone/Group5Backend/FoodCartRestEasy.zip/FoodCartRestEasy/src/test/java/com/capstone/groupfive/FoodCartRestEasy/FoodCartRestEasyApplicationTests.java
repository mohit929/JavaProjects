package com.capstone.groupfive.FoodCartRestEasy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodCartRestEasyApplicationTests {

	@Test
	void contextLoads() {
	}

}
